<?php
/**
 * Contains the database configuration in which the application would use to access the
 * database
 * @author Bill Glinton <tom.omuom@strathmore.edu>
 * @version 1.0.0
 */

$servername = "localhost"; // Host

$username = "id17436567_mobile_app"; // Username

$password = "uYlV.@ZC5liTc-rm"; // Password

$database = "id17436567_golf_zone"; // Database Name


?>